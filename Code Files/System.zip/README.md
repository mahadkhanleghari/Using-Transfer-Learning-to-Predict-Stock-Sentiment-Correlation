# Stocks_Sentiment_Analysis

1. After the environment has been set up, Charlie Main File is the main that has to be run. 
2. It takes the company name, the article date, the date range and the stock ticker as
input. 
3. It should return article headlines, related article headlines to company,
The correlation and also a company_out file which displays the stock properties.